<?php
require_once('config.php');


$v = array('testVariable' => "wartość testowa",);
$twig ->display('test.html.twig');
?>